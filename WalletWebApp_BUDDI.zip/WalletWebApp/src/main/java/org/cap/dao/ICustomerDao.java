package org.cap.dao;

import java.util.List;

import org.cap.model.Account;
import org.cap.model.Customer;

public interface ICustomerDao {

	public boolean createCustomer(Customer customer);

	public Customer findCustomer(Integer custId);

	public boolean createAccount(Account acc);
	public Customer isValidLogin(Customer loginPojo);

	public List<Account> getAccounts(Integer custId);
}
