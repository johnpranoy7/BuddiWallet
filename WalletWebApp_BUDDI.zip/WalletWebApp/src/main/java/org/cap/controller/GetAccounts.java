package org.cap.controller;

import java.io.IOException;
import java.io.PrintWriter;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.cap.model.Account;
import org.cap.model.Customer;
import org.cap.service.CustomerServiceImpl;
import org.cap.service.ICustomerService;


@WebServlet("/GetAccounts")
public class GetAccounts extends HttpServlet {
	private static final long serialVersionUID = 1L;
	private static ICustomerService service=new CustomerServiceImpl();
	
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		HttpSession session=request.getSession(false);
		Integer custId=(Integer)session.getAttribute("customerid");
		List<Account> accounts=service.getAccounts(custId);
		for(Account account:accounts){
			PrintWriter out=response.getWriter();
			out.println("<html><head>hi</head> </html>");
		}
	}

}
