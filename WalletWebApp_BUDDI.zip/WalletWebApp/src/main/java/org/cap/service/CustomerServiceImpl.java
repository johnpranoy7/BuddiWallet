package org.cap.service;

import java.util.List;

import org.cap.dao.CustomerDaoImpl;
import org.cap.dao.ICustomerDao;
import org.cap.model.Account;
import org.cap.model.Customer;

public class CustomerServiceImpl implements ICustomerService {

	private ICustomerDao customerDao;
	
	public CustomerServiceImpl() {
		customerDao=new CustomerDaoImpl();
	}
	
	@Override
	public boolean createCustomer(Customer customer) {
		
		return customerDao.createCustomer(customer);
	}

	@Override
	public Customer findCustomer(Integer custId) {
		return customerDao.findCustomer(custId);
	}

	@Override
	public boolean createAccount(Account acc) {
		
		return customerDao.createAccount(acc);
	}
	@Override
	public Customer isValid(Customer detail) {
		return(customerDao.isValidLogin(detail)); 
			
}

	@Override
	public List<Account> getAccounts(Integer custId) {
		return customerDao.getAccounts(custId);
	}
}
